"use strict";
(() => {
var exports = {};
exports.id = 13;
exports.ids = [13];
exports.modules = {

/***/ 99:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 1742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const nodemailer = __webpack_require__(99);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((req, res)=>{
    const { name , email , phone , finalAdress , takeoffAddress , vehicle , vehiclePageFr , vehiclePage , startDate , returnDate , text  } = req.body;
    let status = false;
    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: "lyricslator@gmail.com",
            pass: "dhevafkryxopitdr"
        }
    });
    const mailOption = {
        from: `${email}`,
        to: "lyricslator@gmail.com",
        subject: `New care hire request from ${email} @ rzal`,
        text: `
    Vehicle:${vehicle}

    Vehicle Front Page:${vehiclePageFr}

    Vehicle Admin Page:${vehiclePage}

    Client Name: ${name}

    Client Email: ${email}

    Client Phone: ${phone}

    FinalAdress: ${finalAdress}

    TakeoffAddress: ${takeoffAddress}

    startDate: ${startDate}

    returnDate: ${returnDate}

    comments: ${text}
    `
    };
    transporter.sendMail(mailOption, (err, data)=>{
        if (err) {
            console.log(err);
            res.json({
                emailStatus: false,
                msg: err
            });
        } else {
            console.log("mail sent");
            res.json({
                emailStatus: true,
                msg: "mail sent"
            });
        }
    });
    console.log(name, email, text);
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1742));
module.exports = __webpack_exports__;

})();
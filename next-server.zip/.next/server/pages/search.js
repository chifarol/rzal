"use strict";
(() => {
var exports = {};
exports.id = 603;
exports.ids = [603,511];
exports.modules = {

/***/ 2661:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/air-conditioned.5e596b51.svg","height":16,"width":16,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 3865:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/doors.5b6b3a0c.svg","height":16,"width":16,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 7814:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/seats.5b6b3a0c.svg","height":16,"width":16,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 5460:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/transmission.8662eff9.svg","height":16,"width":16,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 1727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SearchPage)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./assets/images/air-conditioned.svg
var air_conditioned = __webpack_require__(2661);
// EXTERNAL MODULE: ./assets/images/arrow-left.svg
var arrow_left = __webpack_require__(5469);
// EXTERNAL MODULE: ./assets/images/doors.svg
var doors = __webpack_require__(3865);
// EXTERNAL MODULE: ./assets/images/seats.svg
var seats = __webpack_require__(7814);
;// CONCATENATED MODULE: ./assets/images/filter.svg
/* harmony default export */ const filter = ({"src":"/_next/static/media/filter.2dceb3de.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./assets/images/search.svg
/* harmony default export */ const search = ({"src":"/_next/static/media/search.67e8c0cb.svg","height":16,"width":16,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./assets/images/transmission.svg
var transmission = __webpack_require__(5460);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./assets/images/no-results.svg
/* harmony default export */ const no_results = ({"src":"/_next/static/media/no-results.ba529eaa.svg","height":500,"width":500,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./components/NoResult.tsx




const NoResult = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "tw-w-full tw-flex tw-flex-col tw-gap-[1rem] tw-items-center",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "tw-w-[20rem] tw-h-[auto] md:tw-w-[15rem]",
                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                    fill: true,
                    src: no_results,
                    alt: "404 image",
                    className: "!tw-relative",
                    style: {
                        objectFit: "cover"
                    }
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("p", {
                className: "tw-uppercaset tw-text-n1",
                children: "No Results found"
            })
        ]
    });
};
/* harmony default export */ const components_NoResult = (NoResult);
{
/* <a href="https://storyset.com/web">Web illustrations by Storyset</a> */ }
// EXTERNAL MODULE: ./components/loaders/PageLoader.tsx
var PageLoader = __webpack_require__(2191);
;// CONCATENATED MODULE: ./components/search/SearchPage.tsx














const Searchpage = ({ vehiclesData: vData , modelsData: mData , manfData: mfData  })=>{
    const router = (0,router_namespaceObject.useRouter)();
    const vehiclesResult = vData;
    const modelsResult = mData;
    const manufacturersResult = mfData;
    const [mobileFilter, setMobileFilter] = (0,external_react_.useState)(false);
    const [manufacturers, setManufacturers] = (0,external_react_.useState)([]);
    const [vehicles, setVehicles] = (0,external_react_.useState)([]);
    const [models, setModels] = (0,external_react_.useState)([]);
    const [modelSearch, setModelSearch] = (0,external_react_.useState)([
        ""
    ]);
    const [manfSearch, setManfSearch] = (0,external_react_.useState)([
        ""
    ]);
    const [searchTerm, setSearchTerm] = (0,external_react_.useState)("");
    (0,external_react_.useEffect)(()=>{
        setManufacturers(manufacturersResult);
    }, [
        manufacturersResult
    ]);
    (0,external_react_.useEffect)(()=>{
        const modelData = modelsResult;
        setModels(modelData);
    }, [
        modelsResult
    ]);
    // when next router is ready
    (0,external_react_.useEffect)(()=>{
        const modelSearchArray = models?.map((model)=>model.slug);
        const modelQuery = router.query.model;
        if (modelQuery && modelQuery !== "all") {
            // console.log("modelQuery", modelQuery);
            setModelSearch([
                modelQuery
            ]);
        } else {
            setModelSearch(modelSearchArray);
        }
    }, [
        models,
        router
    ]);
    (0,external_react_.useEffect)(()=>{
        const manfSearchArray = manufacturers?.map((manf)=>manf.slug);
        const manfQuery = router.query.manufacturer;
        if (manfQuery && manfQuery !== "all") {
            // console.log("modelQuery", manfQuery);
            setManfSearch([
                manfQuery
            ]);
        } else {
            setManfSearch(manfSearchArray);
        }
    }, [
        manufacturers,
        router
    ]);
    (0,external_react_.useEffect)(()=>{
        const modelQuery = router.query.model;
        const manfQuery = router.query.manufacturer;
        if (modelQuery && modelQuery !== "all") {
            let vehicleFilter = vehiclesResult?.filter((vehicle, index)=>vehicle.acf.vehicle_model.post_name == modelQuery);
            setVehicles(vehicleFilter);
        } else if (manfQuery && manfQuery !== "all") {
            let vehicleFilter = vehiclesResult?.filter((vehicle, index)=>vehicle.acf.vehicle_manufacturer.post_name == manfQuery);
            setVehicles(vehicleFilter);
        } else {
            setVehicles(vehiclesResult);
        }
    }, [
        vehiclesResult
    ]);
    (0,external_react_.useEffect)(()=>{
    // console.log("vehicles", vehicles);
    }, [
        vehicles
    ]);
    (0,external_react_.useEffect)(()=>{
        let v = vehiclesResult?.map((item)=>item);
        if (searchTerm.length > 0) {
            let vehicleFilter = v?.filter((vehicle, index)=>{
                if (modelSearch?.includes(vehicle.acf.vehicle_model.post_name) && manfSearch?.includes(vehicle.acf.vehicle_manufacturer.post_name) && (vehicle.slug.includes(searchTerm) || vehicle.title.rendered.includes(searchTerm))) {
                    return vehicle;
                }
            });
            setVehicles(vehicleFilter);
        // console.log("vehicleFilter w search", vehicleFilter);
        } else {
            let vehicleFilter = v?.filter((vehicle, index)=>modelSearch.includes(vehicle.acf.vehicle_model.post_name) && manfSearch.includes(vehicle.acf.vehicle_manufacturer.post_name));
            setVehicles(vehicleFilter);
        // console.log("vehicleFilter empty search", vehicleFilter);
        }
    }, [
        manfSearch,
        searchTerm,
        modelSearch
    ]);
    // useEffect(() => {
    //   if (!searchTerm) {
    //     // setVehicles(vehiclesResult);
    //   } else {
    //     let v: VehicleArrayType = vehiclesResult;
    //     let vehicleFilter = v?.filter(
    //       (vehicle, index) =>
    //         vehicle.slug.includes(searchTerm) ||
    //         vehicle.title.rendered.includes(searchTerm)
    //     );
    //     setVehicles(vehicleFilter);
    //     console.log("vehicleFilter", vehicleFilter);
    //   }
    // }, [searchTerm]);
    function addRemoveString(arr, target, isChecked) {
        let arrClone = arr.map((item)=>item);
        // console.log("isChecked", isChecked);
        // console.log("target", target);
        // console.log("arrClone before", arrClone);
        if (isChecked) {
            arrClone.push(target);
        } else {
            arrClone = arrClone.filter((e)=>e != target);
        }
        // console.log("arrClone after", arrClone);
        return arrClone;
    }
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "tw-p-[4rem] md:tw-p-[1.5rem] tw-text-n1",
        children: !vehiclesResult || !modelsResult || !manufacturersResult ? /*#__PURE__*/ jsx_runtime.jsx(PageLoader/* default */.Z, {}) : /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "tw-w-[fit-content] tw-pl-[2rem] tw-mt-[-4.5rem] tw-fixed tw-bottom-[2rem] tw-left-[2rem] tw-z-[10] pointer tw-hidden md:tw-block",
                    onClick: ()=>setMobileFilter(!mobileFilter),
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "tw-ml-[-3rem] tw-h-[3rem] tw-w-[3rem] tw-grid tw-place-items-center tw-bg-s1 tw-rounded-[100px] sh-24",
                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                alt: "whatsapp-icon",
                                width: 32,
                                height: 32,
                                className: "",
                                src: filter
                            })
                        }),
                        mobileFilter && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "tw-p-[1rem] tw-absolute tw-top-[-33rem] tw-left-[1rem] tw-bg-s1 sh-24 tw-rounded-[12px] tw-w-[14rem]",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("h4", {
                                    className: "tw-font-bold",
                                    children: "FILTERS"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "tw-flex tw-flex-col tw-gap-[1rem] tw-mt-[1.5rem]",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "tw",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "tw-text-n5",
                                                    onClick: ()=>{
                                                    // console.log(modelSearch)
                                                    },
                                                    children: "Type"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "tw-flex tw-flex-col tw-gap-[.5rem] tw-mt-[.5rem]",
                                                    children: models?.map((model, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "tw-flex tw-items-center tw-gap-[.5rem]",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                                    className: "checkbox-container",
                                                                    htmlFor: model.slug,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                                            type: "checkbox",
                                                                            checked: modelSearch?.includes(model.slug),
                                                                            id: model.slug,
                                                                            onChange: (e)=>{
                                                                                setModelSearch(addRemoveString(modelSearch, model.slug, e.target.checked));
                                                                            }
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "checkmark"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                    className: "tw",
                                                                    children: model.title.rendered
                                                                })
                                                            ]
                                                        }, index))
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "tw",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "tw-text-n5",
                                                    onClick: ()=>{
                                                    // console.log(manfSearch)
                                                    },
                                                    children: "Manufacturer"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "tw-flex tw-flex-col tw-gap-[.5rem] tw-mt-[.5rem]",
                                                    children: manufacturers?.map((manf, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "tw-flex tw-items-center tw-gap-[.5rem]",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                                    className: "checkbox-container",
                                                                    htmlFor: manf.slug,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                                            type: "checkbox",
                                                                            checked: manfSearch?.includes(manf.slug),
                                                                            id: manf.slug,
                                                                            onChange: (e)=>{
                                                                                setManfSearch(addRemoveString(manfSearch, manf.slug, e.target.checked));
                                                                            }
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "checkmark"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                    className: "tw",
                                                                    children: manf.title.rendered
                                                                })
                                                            ]
                                                        }, index))
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    onClick: ()=>window.history.back(),
                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                        className: "!tw-relative pointer tw-mb-[1rem]",
                        src: arrow_left/* default */.Z,
                        height: 24,
                        width: 24,
                        alt: "vehicle",
                        style: {
                            objectFit: "cover"
                        }
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "tw-grid tw-grid-cols-[1fr_4fr] tw-gap-[2rem] md:tw-grid-cols-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "tw md:tw-hidden",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("h4", {
                                    className: "tw-font-bold",
                                    children: "FILTERS"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "tw-flex tw-flex-col tw-gap-[2rem] tw-mt-[3rem]",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "tw",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "tw-text-n5",
                                                    onClick: ()=>{
                                                        console.log(modelSearch);
                                                    },
                                                    children: "Type"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "tw-flex tw-flex-col tw-gap-[.5rem] tw-mt-[.5rem]",
                                                    children: models?.map((model, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "tw-flex tw-items-center tw-gap-[.5rem]",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                                    className: "checkbox-container",
                                                                    htmlFor: model.slug,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                                            type: "checkbox",
                                                                            checked: modelSearch?.includes(model.slug),
                                                                            id: model.slug,
                                                                            onChange: (e)=>{
                                                                                setModelSearch(addRemoveString(modelSearch, model.slug, e.target.checked));
                                                                            }
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "checkmark"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                    className: "tw",
                                                                    children: model.title.rendered
                                                                })
                                                            ]
                                                        }, index))
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "tw",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "tw-text-n5",
                                                    onClick: ()=>{
                                                    // console.log(manfSearch)
                                                    },
                                                    children: "Manufacturer"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "tw-flex tw-flex-col tw-gap-[.5rem] tw-mt-[.5rem]",
                                                    children: manufacturers?.map((manf, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "tw-flex tw-items-center tw-gap-[.5rem]",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                                    className: "checkbox-container",
                                                                    htmlFor: manf.slug,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                                            type: "checkbox",
                                                                            checked: manfSearch?.includes(manf.slug),
                                                                            id: manf.slug,
                                                                            onChange: (e)=>{
                                                                                setManfSearch(addRemoveString(manfSearch, manf.slug, e.target.checked));
                                                                            }
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "checkmark"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                    className: "tw",
                                                                    children: manf.title.rendered
                                                                })
                                                            ]
                                                        }, index))
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "tw",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "tw-relative",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                            height: 16,
                                            width: 16,
                                            alt: "vehicle",
                                            src: search,
                                            className: "tw-h-[1rem] tw-absolute tw-top-[1.25rem] tw-left-[0.75rem]"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("input", {
                                            type: "text",
                                            placeholder: "Search vehicles",
                                            className: "tw-bg-[#F5F5F8] tw-rounded-[4px] tw-w-[100%] tw-p-[1rem_2.5rem] tw-text-[1rem]",
                                            onChange: (e)=>setSearchTerm(e.target.value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "tw-text-n4 tw-mt-[2rem] md:tw-mt-[1rem]",
                                    onClick: ()=>{
                                    // console.log("vehiclescat", vehicles)
                                    },
                                    children: [
                                        "Showing ",
                                        vehicles?.length,
                                        " of ",
                                        vehiclesResult?.length
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "tw-grid md:tw-grid-cols-2 tw-grid-cols-3 tw-justify-center tw-gap-[2rem] tw-mt-[1rem] s:tw-flex s:tw-flex-col md:tw-mt-[.5rem]",
                                    children: vehicles?.map((vehicle, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                            href: `/details/${vehicle.slug}`,
                                            className: "tw-flex tw-flex-col tw-w-full car-grid-item sm:tw-w-full",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "tw-w-full tw-h-[12.5rem] tw-bg-s3 tw-rounded-[12px]",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                        className: "!tw-relative",
                                                        src: vehicle.acf.main_image,
                                                        fill: true,
                                                        alt: "vehicle",
                                                        style: {
                                                            objectFit: "cover"
                                                        }
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "tw-flex tw-flex-col tw-p-[1rem] tw-bg-s1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("h6", {
                                                            className: "tw-text-n1 tw-text-24 tw-font-bold md:tw-text-20 truncate-sm",
                                                            children: vehicle.acf.vehicle_name
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                            className: "tw-text-n3",
                                                            children: vehicle.acf.vehicle_manufacturer.post_title
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "tw-flex tw-flex-wrap tw-gap-[.5rem] tw-mt-[1rem] md:tw-grid-cols-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                    className: "tw-flex tw-gap-[.5rem] tw-items-center",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                            className: "tw",
                                                                            src: doors/* default */.Z,
                                                                            height: 16,
                                                                            width: 16,
                                                                            alt: "vehicle"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                                            className: "tw-text-n3",
                                                                            children: [
                                                                                vehicle.acf.number_of_doors,
                                                                                " Doors"
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                    className: "tw-flex tw-gap-[.5rem] tw-items-center",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                            className: "tw",
                                                                            src: seats/* default */.Z,
                                                                            height: 16,
                                                                            width: 16,
                                                                            alt: "vehicle"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                                            className: "tw-text-n3",
                                                                            children: [
                                                                                vehicle.acf.number_of_seats,
                                                                                " Seats"
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                    className: "tw-flex tw-gap-[.5rem] tw-items-center",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                            className: "tw",
                                                                            src: transmission/* default */.Z,
                                                                            height: 16,
                                                                            width: 16,
                                                                            alt: "vehicle"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                            className: "tw-text-n3",
                                                                            children: vehicle.acf.transmission
                                                                        })
                                                                    ]
                                                                }),
                                                                vehicle.acf.airconditioned && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                    className: "tw-flex tw-gap-[.5rem] tw-items-center",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                            className: "tw",
                                                                            src: air_conditioned/* default */.Z,
                                                                            height: 16,
                                                                            width: 16,
                                                                            alt: "vehicle"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                            className: "tw-text-n3",
                                                                            children: "Air Conditioned"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index))
                                }),
                                !vehicles?.length && /*#__PURE__*/ jsx_runtime.jsx(components_NoResult, {})
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const SearchPage = (Searchpage);


/***/ }),

/***/ 2314:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Search),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8725);
/* harmony import */ var _components_nav_foot_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7363);
/* harmony import */ var _components_search_SearchPage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1727);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2905);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_4__, html_react_parser__WEBPACK_IMPORTED_MODULE_5__]);
([axios__WEBPACK_IMPORTED_MODULE_4__, html_react_parser__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function Search({ vehiclesData , modelsData , manfData  }) {
    const fullHead = (0,html_react_parser__WEBPACK_IMPORTED_MODULE_5__["default"])(vehiclesData[0].yoast_head || "");
    // console.log("fullHead", fullHead, "yoast_head", vehiclesData[0].yoast_head);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout__WEBPACK_IMPORTED_MODULE_1__["default"], {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_nav_foot_Navbar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                fill: "#171020"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_6___default()), {
                children: [
                    fullHead,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Search Vehicles - Rzal Car Hire"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search_SearchPage__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    vehiclesData: vehiclesData,
                    modelsData: modelsData,
                    manfData: manfData
                })
            })
        ]
    });
}
const getStaticProps = async ({ params  })=>{
    let vehiclesData = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get("http://localhost:10006" + `/wp-json/wp/v2/vehicles?acf_format=standard&_fields[]=id&_fields[]=title&_fields[]=slug&_fields[]=featured_media&_fields[]=guid&_fields[]=acf&_fields[]=yoast_head&_fields[]=yoast_head_json`).then((res)=>res.data);
    vehiclesData = vehiclesData.filter((x, index)=>index < 7);
    const modelsData = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get("http://localhost:10006" + `/wp-json/wp/v2/vehicle_models?acf_format=standard&_fields[]=id&_fields[]=title&_fields[]=slug&_fields[]=acf&_fields[]=yoast_head&_fields[]=yoast_head_json`).then((res)=>res.data);
    const manfData = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get("http://localhost:10006" + `/wp-json/wp/v2/vehicle_manufacturers?acf_format=standard&_fields[]=id&_fields[]=title&_fields[]=slug&_fields[]=acf&_fields[]=yoast_head&_fields[]=yoast_head_json`).then((res)=>res.data);
    // console.log("vehiclesData", vehiclesData);
    return {
        props: {
            vehiclesData,
            modelsData,
            manfData
        },
        revalidate: 60 * 60 * 24
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,636,61,725,363,354], () => (__webpack_exec__(2314)));
module.exports = __webpack_exports__;

})();
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6161:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./styles/fonts.css
var fonts = __webpack_require__(3806);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: ./store/features/menuOpenSlice.ts
var menuOpenSlice = __webpack_require__(5853);
;// CONCATENATED MODULE: ./store/store.ts


const store = (0,toolkit_.configureStore)({
    reducer: {
        menuOpen: menuOpenSlice/* default */.ZP
    }
});
/* harmony default export */ const store_store = (store);

;// CONCATENATED MODULE: ./pages/_app.tsx


// import "../styles/bootstrap.css";



function App({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime.jsx(external_react_redux_.Provider, {
        store: store_store,
        children: /*#__PURE__*/ jsx_runtime.jsx(Component, {
            ...pageProps
        })
    });
}


/***/ }),

/***/ 5853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wf": () => (/* binding */ selectMenuIsOpen),
/* harmony export */   "Wj": () => (/* binding */ closeMenu),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "qn": () => (/* binding */ openMenu)
/* harmony export */ });
/* unused harmony export menuOpenSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    menuIsOpen: false
};
const menuOpenSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "menuOpen",
    initialState,
    reducers: {
        openMenu: (state)=>{
            state.menuIsOpen = true;
        // console.log('menuIsOpen true')
        },
        closeMenu: (state)=>{
            state.menuIsOpen = false;
        // console.log('menuIsOpen false')
        }
    }
});
const { openMenu , closeMenu  } = menuOpenSlice.actions;
// Other code such as selectors can use the imported `RootState` type
const selectMenuIsOpen = (state)=>state.menuOpen.menuIsOpen;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (menuOpenSlice.reducer);


/***/ }),

/***/ 3806:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893], () => (__webpack_exec__(6161)));
module.exports = __webpack_exports__;

})();
"use strict";
(() => {
var exports = {};
exports.id = 325;
exports.ids = [325,511];
exports.modules = {

/***/ 7458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_details_HireForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6661);
/* harmony import */ var _assets_images_arrow_left_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5469);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _loaders_PageLoader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2191);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_details_HireForm__WEBPACK_IMPORTED_MODULE_2__]);
_components_details_HireForm__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Detailspage = ({ vehicleData  })=>{
    // console.log("vehicleData", vehicleData);
    const [currentImage, setCurrentImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setCurrentImage(vehicleData.acf.main_image);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "tw-p-[4rem] md:tw-p-[1.5rem] tw-text-n1",
        children: !vehicleData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loaders_PageLoader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: ()=>window.history.back(),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                        className: "!tw-relative pointer",
                        src: _assets_images_arrow_left_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                        height: 24,
                        width: 24,
                        alt: "vehicle",
                        style: {
                            objectFit: "cover"
                        }
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "tw-grid tw-grid-cols-[1fr_3fr] tw-gap-[2rem] md:tw-grid-cols-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "tw-mt-[3rem] md:tw-mt-0",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "tw md:tw-hidden",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "tw-font-bold",
                                        children: "DETAILS"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "tw-flex tw-flex-col tw-gap-[2rem] tw-mt-[3rem]",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "tw-flex tw-flex-col tw-gap-[.5rem] tw-mt-[.5rem]",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n4",
                                                            children: "Avalability"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n1",
                                                            children: vehicleData.acf.available ? "available" : "unavailable"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n4",
                                                            children: "Transmission"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n1",
                                                            children: vehicleData.acf.transmission
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n4",
                                                            children: "Doors"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n1",
                                                            children: vehicleData.acf.number_of_doors
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n4",
                                                            children: "Seats"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n1",
                                                            children: vehicleData.acf.number_of_seats
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n4",
                                                            children: "Air Conditioned"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "tw-text-n1",
                                                            children: vehicleData.acf.airconditioned ? "Yes" : "No"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                    href: "#hire-contact-form",
                                                    className: "pointer tw-mt-[1rem] tw-bg-p4 tw-text-s2 tw-p-[.5rem_1rem] tw-rounded-[.25rem] md:tw-p-[.5rem]tw-w-full tw-text-center",
                                                    children: "Hire"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "tw-text-32 tw-uppercase tw-text-n1 tw-font-bold tw-mb-[1rem] md:tw-mb-[.5rem] md:tw-text-20",
                                    onClick: ()=>{
                                    // console.log("vehicleDatacat", vehicleData)
                                    },
                                    children: vehicleData.acf.vehicle_name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "tw-flex tw-flex-col tw-mt-[1rem] tw-gap-[1rem] tw-mt-[1rem] md:tw-mt-[.5rem]",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "tw-flex tw-flex-col tw-w-full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "tw-w-full tw-h-[30rem] tw-bg-s3 tw-rounded-[12px] sm:tw-h-[15rem]",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    className: "!tw-relative",
                                                    src: currentImage,
                                                    fill: true,
                                                    alt: "vehicle",
                                                    style: {
                                                        objectFit: "cover"
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "tw-grid tw-grid-cols-6 tw-gap-[1rem] tw-justify-between tw-mt-[1rem] md:tw-grid-cols-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "tw-w-full tw-h-[120px] sm:tw-h-[6rem]",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            className: "!tw-relative pointer",
                                                            src: vehicleData.acf.main_image,
                                                            onClick: ()=>setCurrentImage(vehicleData.acf.main_image),
                                                            fill: true,
                                                            alt: "vehicle",
                                                            style: {
                                                                objectFit: "cover"
                                                            }
                                                        })
                                                    }),
                                                    vehicleData.acf.images?.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "tw-bg-s3 tw-w-full tw-h-[120px] sm:tw-h-[6rem] tw-flex tw-justify-center",
                                                            onClick: ()=>setCurrentImage(image.full_image_url),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                className: "!tw-relative pointer",
                                                                src: image.thumbnail_image_url,
                                                                fill: true,
                                                                alt: "vehicle",
                                                                style: {
                                                                    objectFit: "cover"
                                                                }
                                                            }, index)
                                                        }, index))
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "tw-mt-[2rem] tw-mt-[1.5rem]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                            className: "tw-font-bold",
                                            children: "DESCRIPTION"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "tw-text-n3",
                                            children: vehicleData.acf.vehicle_description
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "tw-hidden md:tw-block tw-mt-[2rem]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                            className: "tw-font-bold",
                                            children: "DETAILS"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "tw-flex tw-flex-col tw-gap-[2rem] tw-mt-[.5rem]",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "tw-flex tw-flex-col tw-gap-[.5rem] tw-mt-[.5rem]",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n4",
                                                                children: "Avalability"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n1",
                                                                children: vehicleData.acf.available ? "available" : "unavailable"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n4",
                                                                children: "Transmission"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n1",
                                                                children: vehicleData.acf.transmission
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n4",
                                                                children: "Doors"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n1",
                                                                children: vehicleData.acf.number_of_doors
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n4",
                                                                children: "Seats"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n1",
                                                                children: vehicleData.acf.number_of_seats
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "tw-flex tw-items-center tw-justify-between tw-gap-[.5rem] border-s7-bottom",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n4",
                                                                children: "Air Conditioned"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "tw-text-n1",
                                                                children: vehicleData.acf.airconditioned ? "Yes" : "No"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_details_HireForm__WEBPACK_IMPORTED_MODULE_2__/* .HireForm */ .V, {
                                    vehicleData: vehicleData
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Detailspage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6661:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ HireForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_4__]);
axios__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const HireForm = ({ vehicleData  })=>{
    const [account, setAccount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        startdate: "",
        enddate: ""
    });
    const [isSending, setIsSending] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [emailMsg, setEmailMsg] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        text: "",
        success: false
    });
    function showPickerS() {
        startDateRef.current.showPicker();
    }
    function showPickerE() {
        returnDateRef.current.showPicker();
    }
    const formRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const fnameRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const emailRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const phoneRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const finalAdressRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const takeoffAddressRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const messageRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const startDateRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const returnDateRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    function submitForm(e) {
        console.dir(formRef.current);
        e.preventDefault();
        setIsSending(true);
        formRef.current.reportValidity();
        if (!formRef.current.reportValidity()) {
            setEmailMsg({
                text: "some fields are missing",
                success: false
            });
            setIsSending(false);
            return;
        }
        // console.log(fnameRef.current.value, emailRef.current.value, messageRef.current.value);
        axios__WEBPACK_IMPORTED_MODULE_4__["default"].post("/api/hire", {
            name: fnameRef.current.value,
            email: emailRef.current.value,
            phone: phoneRef.current.value,
            finalAdress: finalAdressRef.current.value,
            takeoffAddress: takeoffAddressRef.current.value,
            vehicle: vehicleData.title.rendered,
            vehiclePageFr: window.location.href,
            vehiclePage: vehicleData.guid.rendered,
            startDate: startDateRef.current.value,
            returnDate: returnDateRef.current.value,
            text: messageRef.current.value
        }).then((res)=>{
            // console.log("mail status", res);
            setIsSending(false);
            if (res.data.emailStatus) {
                setEmailMsg({
                    text: "Your request was submitted successfully. One of our representatives will contact you shortly.",
                    success: true
                });
                window.location.hash = "hire-contact-form";
            } else {
                setEmailMsg({
                    text: "Your request could not be sent please try again later.",
                    success: false
                });
            }
        }).catch((err)=>{
        // console.log("mail error", err.message);
        });
    }
    function handleChange(e) {
        const name = e.target.name;
        const value = e.target.value;
        // treat state as immutable!
        // you need to creaet a new object here
        // See https://stackoverflow.com/a/25333702/17487348 for how to create a property from a string in ES6
        setAccount({
            ...account,
            [name]: value
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "tw-bg-s3 tw-p-[1.5rem] tw-mt-[3rem] tw-max-w-[70rem] tw-mx-[auto] md:tw-p-[2.5rem_1.5rem] tw-text-neutral-0d",
        id: "hire-contact-form",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "tw-bg-yellow-f3 tw-justify-center tw-items-center",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                action: "",
                ref: formRef,
                method: "post",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "tw-text-24 tw-text-n1",
                        children: "HIRE THIS VEHICLE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "tw-text-n4 tw-font-medium tw-mt-[1rem]",
                        children: "Kindly fill our form with your details and one of our representatives will contact you shortly."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: `${emailMsg.success ? "text-success" : "text-danger"} tw-mt-[1rem]`,
                        children: emailMsg.text
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "tw-mt-[.5rem] tw-grid tw-gap-[1rem]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Vehicle"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        placeholder: "",
                                        defaultValue: vehicleData.title.rendered,
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        readOnly: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Name*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: fnameRef,
                                        type: "text",
                                        placeholder: "Enter your name",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Email*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: emailRef,
                                        type: "email",
                                        placeholder: "Enter your email",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Phone No*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: phoneRef,
                                        type: "text",
                                        placeholder: "Enter your phone number",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Take Off Address*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: takeoffAddressRef,
                                        type: "text",
                                        placeholder: "Enter take off address",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Final Address"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: finalAdressRef,
                                        type: "text",
                                        placeholder: "Enter final address",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "tw-flex tw-items-center tw-gap-[1.5rem]",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "tw-flex tw-flex-col tw-w-[100%]",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Pickup Date"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "date",
                                                className: "tw-h-[3.5rem] tw-mt-[0.5rem]  tw-w-[100%] tw-p-[1rem] sm:tw-max-w-[130px]",
                                                id: "date",
                                                name: "startdate",
                                                ref: startDateRef,
                                                min: new Date().toISOString().split("T")[0],
                                                onFocus: showPickerS,
                                                onClick: showPickerS,
                                                onChange: handleChange,
                                                required: true
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "tw-flex tw-flex-col tw-w-[100%]",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Return Date"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "date",
                                                className: "tw-h-[3.5rem] tw-mt-[0.5rem]  tw-w-[100%] tw-p-[1rem] sm:tw-max-w-[130px]",
                                                id: "date",
                                                name: "enddate",
                                                ref: returnDateRef,
                                                min: account.startdate ? new Date(account.startdate).toISOString().split("T")[0] : "",
                                                onFocus: showPickerE,
                                                onClick: showPickerE,
                                                onChange: handleChange,
                                                required: true
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Any other thing you would like us to know?"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        ref: messageRef,
                                        name: "",
                                        id: "",
                                        cols: "1",
                                        rows: "4",
                                        className: "tw-min-h-[5.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        defaultValue: ""
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `${isSending || "pointer"} tw-max-w-[fit-content] tw-mt-[1rem] tw-bg-p4 tw-text-s2 tw-p-[.5rem_2rem] tw-rounded-[.25rem] md:tw-p-[.5rem] ] tw-text-center`,
                                onClick: (e)=>submitForm(e),
                                disabled: isSending,
                                children: isSending ? "Sending..." : "Send Request"
                            })
                        ]
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9524:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Post),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8725);
/* harmony import */ var _components_nav_foot_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7363);
/* harmony import */ var _components_details_Detailspage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7458);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2905);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_details_Detailspage__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__, html_react_parser__WEBPACK_IMPORTED_MODULE_5__]);
([_components_details_Detailspage__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__, html_react_parser__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function Post({ vehicleData  }) {
    const fullHead = (0,html_react_parser__WEBPACK_IMPORTED_MODULE_5__["default"])(vehicleData.yoast_head || "");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout__WEBPACK_IMPORTED_MODULE_1__["default"], {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_6___default()), {
                children: [
                    fullHead,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                        children: [
                            "Hire ",
                            vehicleData.title.rendered,
                            " - Vehicle Details - Rzal Car Hire"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_nav_foot_Navbar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                fill: "#171020"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_details_Detailspage__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    vehicleData: vehicleData
                })
            })
        ]
    });
}
async function getStaticPaths() {
    const vehicles = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get("http://localhost:10006" + "/wp-json/wp/v2/vehicles?acf_format=standard").then((res)=>res.data);
    // console.log("vehicles", vehicles);
    let vehicleSlugs = vehicles.map((vehicle)=>({
            params: {
                slug: vehicle.slug
            }
        }));
    return {
        paths: vehicleSlugs,
        fallback: false
    };
}
const getStaticProps = async ({ params  })=>{
    const vehicleData = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get("http://localhost:10006" + `/wp-json/wp/v2/vehicles?acf_format=standard&_fields[]=id&_fields[]=title&_fields[]=slug&_fields[]=featured_media&_fields[]=guid&_fields[]=acf&_fields[]=yoast_head&_fields[]=yoast_head_json`).then((res)=>res.data);
    // console.log("vehicleData", vehicleData);
    return {
        props: {
            vehicleData: vehicleData[0]
        },
        revalidate: 60 * 60 * 24
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,636,61,725,363,354], () => (__webpack_exec__(9524)));
module.exports = __webpack_exports__;

})();
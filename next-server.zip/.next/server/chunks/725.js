"use strict";
exports.id = 725;
exports.ids = [725];
exports.modules = {

/***/ 8725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_Layout)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/images/logo.jpeg
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.333f5363.jpeg","height":1080,"width":1080,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQP/xAAdEAABAwUBAAAAAAAAAAAAAAABAhEUAAQhMUGh/9oACAEBAAE/ABNTelTiMwDd1n2v/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/images/email.svg
/* harmony default export */ const email = ({"src":"/_next/static/media/email.1a4a4f11.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./assets/images/whatsapp-line.svg
/* harmony default export */ const whatsapp_line = ({"src":"/_next/static/media/whatsapp-line.2080ce20.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./assets/images/phone.svg
/* harmony default export */ const phone = ({"src":"/_next/static/media/phone.b1ea4086.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./assets/images/map-pin.svg
/* harmony default export */ const map_pin = ({"src":"/_next/static/media/map-pin.0b61050d.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./assets/images/copyright.svg
/* harmony default export */ const copyright = ({"src":"/_next/static/media/copyright.9b77881a.svg","height":24,"width":25,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/nav-foot/Footer.tsx










const Footer = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "tw-bg-[#171020] tw-flex tw-flex-col tw-gap-[2rem] tw-items-center tw-p-[3rem] tw-mt-[auto] md:tw-gap-[1.5rem] md:tw-p-[2rem_1.5rem] sm:tw-items-start",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                        width: 120,
                        alt: "vehicle",
                        src: logo,
                        className: "!tw-relative tw-h-[auto] md:tw-h-[5rem]"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "tw-flex tw-gap-[2rem] tw-text-20 tw-text-s1 md:tw-text-16",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "/",
                                className: "tw",
                                children: "Home"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "/search?model=all&manufacturer=all",
                                className: "tw",
                                children: "Hire"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "/contact-us",
                                className: "tw",
                                children: "Contact Us"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "tw-flex tw-flex-col tw-items-center tw-gap-[1rem] tw-text-16 tw-text-s1 md:tw-gap-[.5rem] tw-font-light sm:tw-items-start tw-pb-[1rem]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                href: "mailto:ritzassociateslimited@gmail.com?",
                                target: "_blank",
                                className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        alt: "vehicle",
                                        className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                        src: email
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "tw",
                                        children: "ritzassociateslimited@gmail.com"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                href: "https://wa.me/2347060710099",
                                target: "_blank",
                                className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        alt: "vehicle",
                                        className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                        src: whatsapp_line
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "tw",
                                        children: "+234(0)7060710099"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        alt: "vehicle",
                                        className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                        src: phone
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "tw",
                                        children: "+234(0)8121716390"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start sm:tw-max-w-[18rem]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        alt: "vehicle",
                                        className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                        src: map_pin
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "",
                                        children: "7 Captain Olajide George Street, Lekki Phase 1, Lagos State."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start sm:tw-max-w-[18rem]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        alt: "vehicle",
                                        className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                        src: map_pin
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "",
                                        children: "70 AdaGeorge Road, Port Harcourt, Rivers State"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "tw-flex tw-items-center tw-justify-center tw-gap-[1rem] tw-text-16 tw-font-light tw-text-s1 tw-w-full tw-pt-[1rem] sm:tw-justify-start  border-s7-top",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                width: 20,
                                height: 20,
                                alt: "vehicle",
                                className: "tw-h-[1rem]",
                                src: copyright
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                className: "tw",
                                children: "2023 All rights reserved."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "tw-flex tw-ml-[auto] tw-mt-[-4.5rem] tw-items-end tw-sticky tw-bottom-[2rem] tw-right-[2rem]",
                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                    href: "https://wa.me/2347060710099",
                    target: "_blank",
                    className: "tw-ml-[auto] tw-mr-[2rem] tw-h-[3rem] tw-w-[3rem] tw-grid tw-place-items-center tw-bg-[#25D366] tw-rounded-[100px] sh-24",
                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                        alt: "whatsapp-icon",
                        width: 32,
                        height: 32,
                        className: "",
                        src: whatsapp_line
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const nav_foot_Footer = (Footer);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./store/features/menuOpenSlice.ts
var menuOpenSlice = __webpack_require__(5853);
// EXTERNAL MODULE: ./store/hooks.ts
var hooks = __webpack_require__(4586);
;// CONCATENATED MODULE: ./pages/Layout.tsx






const Layout = ({ children  })=>{
    const dispatch = (0,hooks/* useAppDispatch */.T)();
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime.jsx("link", {
                    rel: "icon",
                    type: "image/x-icon",
                    href: "/favicon.jpg"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "tw-w-full tw-font-josefin tw-flex tw-flex-col tw-min-h-[100vh]",
                onClick: ()=>{
                    dispatch((0,menuOpenSlice/* closeMenu */.Wj)());
                },
                children: [
                    children,
                    /*#__PURE__*/ jsx_runtime.jsx(nav_foot_Footer, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const pages_Layout = (Layout);


/***/ }),

/***/ 5853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wf": () => (/* binding */ selectMenuIsOpen),
/* harmony export */   "Wj": () => (/* binding */ closeMenu),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "qn": () => (/* binding */ openMenu)
/* harmony export */ });
/* unused harmony export menuOpenSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    menuIsOpen: false
};
const menuOpenSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "menuOpen",
    initialState,
    reducers: {
        openMenu: (state)=>{
            state.menuIsOpen = true;
        // console.log('menuIsOpen true')
        },
        closeMenu: (state)=>{
            state.menuIsOpen = false;
        // console.log('menuIsOpen false')
        }
    }
});
const { openMenu , closeMenu  } = menuOpenSlice.actions;
// Other code such as selectors can use the imported `RootState` type
const selectMenuIsOpen = (state)=>state.menuOpen.menuIsOpen;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (menuOpenSlice.reducer);


/***/ }),

/***/ 4586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ useAppSelector),
/* harmony export */   "T": () => (/* binding */ useAppDispatch)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

// Use throughout your app instead of plain `useDispatch` and `useSelector`
const useAppDispatch = react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch;
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;


/***/ })

};
;
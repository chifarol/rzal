"use strict";
exports.id = 354;
exports.ids = [354];
exports.modules = {

/***/ 5469:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow-left.8648208c.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 2191:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const PageLoader = (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "tw-w-full tw-flex tw-justify-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "loader loader--style6",
            title: "5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                version: "1.1",
                id: "Layer_1",
                x: "0px",
                y: "0px",
                viewBox: "0 0 24 30",
                className: "tw-w-[100px] tw-h-[100px] page-loader-svg",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("rect", {
                        x: "0",
                        y: "13",
                        width: "4",
                        height: "5",
                        fill: "#333",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("animate", {
                                attributeName: "height",
                                attributeType: "XML",
                                values: "5;21;5",
                                begin: "0s",
                                dur: "0.6s",
                                repeatCount: "indefinite"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("animate", {
                                attributeName: "y",
                                attributeType: "XML",
                                values: "13; 5; 13",
                                begin: "0s",
                                dur: "0.6s",
                                repeatCount: "indefinite"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("rect", {
                        x: "10",
                        y: "13",
                        width: "4",
                        height: "5",
                        fill: "#333",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("animate", {
                                attributeName: "height",
                                attributeType: "XML",
                                values: "5;21;5",
                                begin: "0.15s",
                                dur: "0.6s",
                                repeatCount: "indefinite"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("animate", {
                                attributeName: "y",
                                attributeType: "XML",
                                values: "13; 5; 13",
                                begin: "0.15s",
                                dur: "0.6s",
                                repeatCount: "indefinite"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("rect", {
                        x: "20",
                        y: "13",
                        width: "4",
                        height: "5",
                        fill: "#333",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("animate", {
                                attributeName: "height",
                                attributeType: "XML",
                                values: "5;21;5",
                                begin: "0.3s",
                                dur: "0.6s",
                                repeatCount: "indefinite"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("animate", {
                                attributeName: "y",
                                attributeType: "XML",
                                values: "13; 5; 13",
                                begin: "0.3s",
                                dur: "0.6s",
                                repeatCount: "indefinite"
                            })
                        ]
                    })
                ]
            })
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageLoader);


/***/ })

};
;
"use strict";
exports.id = 601;
exports.ids = [601];
exports.modules = {

/***/ 1180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/map-pin-dark.7aad6a3c.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 8106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/phone-dark.c0257375.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 4810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/whatsapp-line-dark.428f9fd2.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 1683:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ ContactForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_4__]);
axios__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ContactForm = ()=>{
    const [isSending, setIsSending] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [emailMsg, setEmailMsg] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        text: "",
        success: false
    });
    const formRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const fnameRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const emailRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const phoneRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const messageRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    function submitForm(e) {
        console.dir(formRef.current);
        e.preventDefault();
        setIsSending(true);
        formRef.current.reportValidity();
        if (!formRef.current.reportValidity()) {
            setEmailMsg({
                text: "some fields are missing",
                success: false
            });
            setIsSending(false);
            return;
        }
        // console.log(fnameRef.current.value, emailRef.current.value, messageRef.current.value);
        axios__WEBPACK_IMPORTED_MODULE_4__["default"].post("/api/contact", {
            name: fnameRef.current.value,
            email: emailRef.current.value,
            phone: phoneRef.current.value,
            text: messageRef.current.value
        }).then((res)=>{
            // console.log("mail status", res);
            setIsSending(false);
            if (res.data.emailStatus) {
                setEmailMsg({
                    text: "Your message was submitted successfully",
                    success: true
                });
                window.location.hash = "hire-contact-form";
            } else {
                setEmailMsg({
                    text: "Your message could not be sent please try again later.",
                    success: false
                });
            }
        }).catch((err)=>{
        // console.log("mail error", err.message);
        });
    }
    function handleChange(e) {
        const name = e.target.name;
        const value = e.target.value;
        // treat state as immutable!
        // you need to creaet a new object here
        // See https://stackoverflow.com/a/25333702/17487348 for how to create a property from a string in ES6
        setAccount({
            ...account,
            [name]: value
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "tw-bg-s3 tw-p-[1.5rem] md:tw-mt-[1rem] tw-max-w-[70rem] tw-mx-[auto] md:tw-p-[2.5rem_1.5rem] tw-text-neutral-0d",
        id: "hire-contact-form",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "tw-bg-yellow-f3 tw-justify-center tw-items-center",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                action: "",
                ref: formRef,
                method: "post",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "tw-text-n4 tw-font-medium tw-mt-[1rem]",
                        children: "Kindly fill our form with your details and one of our representatives will contact you shortly."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: `${emailMsg.success ? "text-success" : "text-danger"} tw-mt-[1rem]`,
                        children: emailMsg.text
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "tw-mt-[.5rem] tw-grid tw-gap-[1rem]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Name*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: fnameRef,
                                        type: "text",
                                        placeholder: "Enter your name",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Email*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: emailRef,
                                        type: "email",
                                        placeholder: "Enter your email",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Phone No*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        ref: phoneRef,
                                        type: "text",
                                        placeholder: "Enter your phone number",
                                        className: "tw-h-[3.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Message"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        ref: messageRef,
                                        name: "",
                                        id: "",
                                        cols: "1",
                                        rows: "4",
                                        className: "tw-min-h-[5.5rem] tw-mt-[0.5rem] tw-p-[1rem] tw-w-[100%]",
                                        defaultValue: ""
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `${isSending || "pointer"} tw-max-w-[fit-content] tw-mt-[1rem] tw-bg-p4 tw-text-s2 tw-p-[.5rem_2rem] tw-rounded-[.25rem] md:tw-p-[.5rem] ] tw-text-center`,
                                onClick: (e)=>submitForm(e),
                                disabled: isSending,
                                children: isSending ? "Sending..." : "Send"
                            })
                        ]
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1601:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_images_whatsapp_line_dark_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4810);
/* harmony import */ var _assets_images_phone_dark_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8106);
/* harmony import */ var _assets_images_map_pin_dark_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1180);
/* harmony import */ var _ContactForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1683);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ContactForm__WEBPACK_IMPORTED_MODULE_6__]);
_ContactForm__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const Contactpage = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "tw-p-[4rem] md:tw-p-[1.5rem] tw-text-n1",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    className: "tw-font-bold tw-text-24 tw-mb-[2rem] md:tw-text-20",
                    children: "CONTACT US"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "tw-grid tw-grid-cols-2 tw-gap-[2rem] md:tw-grid-cols-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ContactForm__WEBPACK_IMPORTED_MODULE_6__/* .ContactForm */ .t, {}),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "tw-flex tw-flex-col tw-gap-[1rem] tw-text-16 tw-text-n1 md:tw-gap-[.5rem] tw-font- sm:tw-items-start tw-pb-[1rem]",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    href: "mailto:ritzassociateslimited@gmail.com?",
                                    target: "_blank",
                                    className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "32",
                                            height: "32",
                                            fill: "#221C29",
                                            viewBox: "0 0 256 256",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48ZM203.43,64,128,133.15,52.57,64ZM216,192H40V74.19l82.59,75.71a8,8,0,0,0,10.82,0L216,74.19V192Z"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "tw",
                                            children: "ritzassociateslimited@gmail.com"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    href: "https://wa.me/2347060710099",
                                    target: "_blank",
                                    className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            width: 32,
                                            height: 32,
                                            alt: "vehicle",
                                            className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                            src: _assets_images_whatsapp_line_dark_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "tw",
                                            children: "+234(0)7060710099"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            width: 32,
                                            height: 32,
                                            alt: "vehicle",
                                            className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                            src: _assets_images_phone_dark_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "tw",
                                            children: "+234(0)8121716390"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start sm:tw-max-w-[18rem]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "32",
                                            height: "32",
                                            fill: "#221C29",
                                            viewBox: "0 0 256 256",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M128,64a40,40,0,1,0,40,40A40,40,0,0,0,128,64Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,128,128Zm0-112a88.1,88.1,0,0,0-88,88c0,31.4,14.51,64.68,42,96.25a254.19,254.19,0,0,0,41.45,38.3,8,8,0,0,0,9.18,0A254.19,254.19,0,0,0,174,200.25c27.45-31.57,42-64.85,42-96.25A88.1,88.1,0,0,0,128,16Zm0,206c-16.53-13-72-60.75-72-118a72,72,0,0,1,144,0C200,161.23,144.53,209,128,222Z"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "",
                                            children: "7 Captain Olajide George Street, Lekki Phase 1, Lagos State."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "tw-flex tw-gap-[.5rem] tw-items-center sm:tw-items-start sm:tw-max-w-[18rem]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            width: 32,
                                            height: 32,
                                            alt: "vehicle",
                                            className: "tw-h-[2rem] md:tw-h-[1.5rem]",
                                            src: _assets_images_map_pin_dark_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "",
                                            children: "70 AdaGeorge Road, Port Harcourt, Rivers State"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contactpage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
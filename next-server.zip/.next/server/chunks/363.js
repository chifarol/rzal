"use strict";
exports.id = 363;
exports.ids = [363];
exports.modules = {

/***/ 7363:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ nav_foot_Navbar)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/images/menu.svg
/* harmony default export */ const menu = ({"src":"/_next/static/media/menu.e529e0ae.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./assets/images/cancel.svg
/* harmony default export */ const cancel = ({"src":"/_next/static/media/cancel.aef82541.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./store/features/menuOpenSlice.ts
var menuOpenSlice = __webpack_require__(5853);
// EXTERNAL MODULE: ./store/hooks.ts
var hooks = __webpack_require__(4586);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/nav-foot/Navbar.tsx








const Navbar = ({ fill ="#221C29"  })=>{
    const dispatch = (0,hooks/* useAppDispatch */.T)();
    const menuIsOpen = (0,hooks/* useAppSelector */.C)(menuOpenSlice/* selectMenuIsOpen */.Wf);
    (0,external_react_.useEffect)(()=>{
    // console.log(menuIsOpen);
    }, [
        menuIsOpen
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: `tw-flex tw-items-center tw-justify-between tw-text-s1 tw-px-[4rem] tw-py-[2rem] tw-bg-[${fill}] md:tw-p-[1rem_1.5rem]`,
        children: [
            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                href: "/",
                className: "tw-text-20 tw-text-bold md:tw-text-16",
                children: "RITZ CAR HIRE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "tw-flex tw-gap-[1.5rem] tw-text-medium tw-text-16 md:tw-hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                        href: "/",
                        className: "tw",
                        children: "Home"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                        href: "/search?model=all&manufacturer=all",
                        className: "tw",
                        children: "Hire"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                        href: "/contact-us",
                        className: "tw",
                        children: "Contact Us"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "tw-relative tw-hidden md:tw-block",
                onClick: (e)=>{
                    e.stopPropagation();
                },
                children: [
                    !menuIsOpen && /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "tw",
                        onClick: ()=>dispatch((0,menuOpenSlice/* openMenu */.qn)()),
                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            width: 48,
                            height: 48,
                            alt: "menu-open",
                            className: "tw-h-[2rem] md:tw-h-[1.5rem] pointer",
                            src: menu
                        })
                    }),
                    menuIsOpen && /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "tw",
                        onClick: ()=>dispatch((0,menuOpenSlice/* closeMenu */.Wj)()),
                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            width: 48,
                            height: 48,
                            alt: "menu-close",
                            className: "tw-h-[2rem] md:tw-h-[1.5rem] pointer",
                            src: cancel
                        })
                    }),
                    menuIsOpen && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "tw-absolute tw-z-[40] tw-p-[.5rem_1rem] tw-right-[0.75rem] tw-top-[2rem] tw-bg-s1 tw-flex tw-flex-col tw-text-n1 tw-w-[150px] tw-rounded-[12px] sh-410",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "#",
                                className: "tw-py-[.5rem] border-s7-bottom",
                                children: "Home"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "#",
                                className: "tw-py-[.5rem] border-s7-bottom",
                                children: "Catalogue"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "#",
                                className: "tw-py-[.5rem] border-s7-bottom",
                                children: "Hire"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "#",
                                className: "tw-py-[.5rem] border-s7-bottom",
                                children: "Contact Us"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const nav_foot_Navbar = (Navbar);


/***/ })

};
;